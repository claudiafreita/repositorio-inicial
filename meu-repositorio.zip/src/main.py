def main():
    print("Olá, Cláudia! 🚀 Seu repositório está funcionando!")

if __name__ == "__main__":
    main()
