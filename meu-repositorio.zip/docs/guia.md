# Guia do Projeto

Este documento explica como o projeto está estruturado e pode ser expandido futuramente.

## Objetivo
Organizar o código e documentação em um repositório bem estruturado.

## Como contribuir
1. Faça um fork do repositório.
2. Crie uma branch com sua modificação.
3. Abra um pull request.
